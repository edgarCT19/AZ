<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel='shortcut icon' type='img/x-icon' href='../img/favicon-removebg-preview.png'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/b1b47db464.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../css/registro.css">


    <title>Registro De Incidencia</title>

    
</head>

<body>
    <section>
        <div class="container">
            <form class="m-4" method="POST">
                <div class="alert alert-primary" role="alert">
                    <h3 style="text-align:center;">INCIDENCIA DEL SERVICIO</h3>
                </div>
                <div class="mb-1">
                    <label for="formGroupExampleInput" class="form-label">Servicio de Negocios</label>
                    
                    <select class="form-select" aria-label="Default select example" name="Nombre" placeholder="Seleccione El Producto">
                        <option value="">HR</option>
                        <option value="">FINANCE</option>
                        <option value="">DEV</option>
                        <option value="">RESEARCH</option>
                        <option value="">OPERATION</option>
                    </select>
                </div>
                <div class="mb-1">

                    <label for="formGroupExampleInput" class="form-label">Prioridad</label>
                    <select class="form-select" aria-label="Default select example" name="Prioridad" placeholder="Seleccione El Producto">
                        <option value="">P1</option>
                        <option value="">P2</option>
                        <option value="">P3</option>
                        <option value="">P4</option>
                    </select>
                </div>
                <div class="mb-1">
                    <label for="formGroupExampleInput" class="form-label">Descripcion</label>
                    <input name="Descripcion" type="text" class="form-control" id="formGroupExampleInput" placeholder="Descripcion" value="">
                </div>
                <div class="mb-1">
                    <label for="formGroupExampleInput" class="form-label">Status</label>
                    <input name="Status" type="text" class="form-control" id="formGroupExampleInput" placeholder="Automatico" value="" disabled>
                </div>
                <div class="mb-1">
                    <label for="formGroupExampleInput" class="form-label">Fecha Y Hora</label>
                    <input name="Fecha_Y_Hora" type="text" class="form-control" id="formGroupExampleInput" placeholder="Automatico" value="" disabled>
                </div>

                <div class="botones">
                    <button type="submit" class="btn btn-primary btn-lg" name="aceptar" value="ok">ACEPTAR</button>
                    <a type="submit" class="btn btn-danger btn-lg" href="inicio.php" value="ok">CANCELAR</a>
                </div>

            </form>
        </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>

</html>