<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="../css/estilos.css">
  <link href="https://fonts.googleapis.com/css?family=Playfair&#43;Display:700,900&amp;display=swap" rel="stylesheet">
  <link rel='shortcut icon' type='img/x-icon' href='../img/favicon-removebg-preview.png'>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous"/>

  <title>Inicio</title>

</head>
<body>

    <!--Seccion del NAVBAR -->
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-lg-12">
          <div style="width: 100%; height: 20vh"> 
            <nav class="navbar navbar-expand-lg bg-whrite">
            <div class="container-fluid">
              <h1 class="navbar-brand text"></h1>
              <img src="../img/LogoOficial.png" style="width: 125px;" alt="logo">
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item dropdown">
                </ul>

                <form class="d-flex box" role="search">
                  <input class="lineH"  type="search" 
                  placeholder="Search..." aria-label="Search" autocomplete="off">
                </form>


              </div>
            </div>
          </nav>
          
          <span class="d-block p-1 text-white borde"></span>

          <nav class="navbar navbar-expand-lg bg-whrite">
            <img src="/img/menu.png" alt="">
            <div class="container-fluid">
              <a class="navbar-brand" href="#"></a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="../Principal_Cuenta/inicio.php">Aplicación</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="../Principal_Cuenta/registro_incidencia.php">Incidencia</a>
                  </li>
                  <li class="nav-item">


<!--seccion de notificaciones-->
<div  class="modal fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content text-bg-danger">
      <div class="modal-header">
        <h3 class="modal-title" id="exampleModalToggleLabel">¡ALERTA!</h3>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <p><h5>¿Qué ha sucedido?</h5></p>
        El área de HR ha reportado que el servicio 3 presenta una problema de prioridad nivel 1.
        <p><h5>Descripción del problema.</h5></p>
        Los servidores web del command center 1 de Guadalajara se han caído y requieren de urgente atención.
      </div>
      <div class="modal-footer">
        <button class="btn btn-light" data-bs-target="#exampleModalToggle2" data-bs-toggle="modal">Ok</button>
      </div>
    </div>
  </div>
</div>  
<button class="btn btn-primary d-inline-flex align-items-center position-relative" data-bs-toggle="modal" href="#exampleModalToggle" role="button">
    <img src="../iconos/notf.svg" alt="" style="width: 20px; height: 20px;">
    <span class="badge text-bg-danger" style="font-size: 10px; width: 20px; height: 18px;">1</span>
</button>
<!--seccion final de noticaciones-->
</li>

                  <li class="nav-item dropdown logout">
<a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
<img src="../iconos/FotoPerfil.svg" alt=""> Juan Perez
                    </a>
                      <ul class="dropdown-menu">
                      <li><a class="dropdown-item" href=""> <img src="../iconos/perfil.svg" alt=""> Perfil</a></li>
                      <li><a class="dropdown-item" href=""><img src="../iconos/expediente.svg" alt="">Historial</a></li>
                      <li><a class="dropdown-item" href="http://localhost/Semaforo_AZ/index.php">
                      <img src="../iconos/logout.svg" alt=""> Cerrar sesión</a></li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </nav>

          <span class="d-block p-1 text-white borde"></span>

        </div>
        </div>
      </div>
    </div>
   <!--Final seccion del NAVBAR -->

  <section class="container text-center">
<h1>Semaforo de servicios</h1>
  </section> 


<!--Sistema alerta-->
<section class="container">
<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>¡URGENTE!</strong> Ha ocurrido un fallo nivel  de prioridad 1. Revisa tu notificación.
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
</section>
<!--Sistema final de alerta-->


    <!--Sección inicial -->


<!--Sección del acordeon 1 -->
<section class="card container">
<div class="accordion accordion-flush container" id="accordionFlushExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingOne">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
        HR
        <div class="spinner-grow text-danger ms-2 spinner-amarillo" role="status">
                <span class="visually-hidden">Loading...</span>
              </div>
      </button>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">

<!-- Tabla dentro del acordeon-->
<section class="container card">
<table class="table container">
  <thead>
    <tr>
      <th scope="col">Numero</th>
      <th scope="col">Nombre del servicio</th>
      <th scope="col">Prioridad</th>
      <th scope="col">Descripcion</th>
      <th scope="col">Fecha y Hora</th>
      <th scope="col">Status</th>
    </tr>
  </thead>

  <tbody >
   
     <tr>
      <th scope="row">3</th>
      <td>Servicio 3</td>
      <td >Nivel 1</td>
      <td>....</td>
      <td>....</td>
      <td><label class="btn btn-danger" style="border-radius:150px;"><img src="../iconos/foco.svg" alt=""></label></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Servicio 2</td>
      <td>Nivel 3</td>
      <td>....</td>
      <td>....</td>
      <td><label for="" class="btn btn-success" style="border-radius:150px;"><img src="../iconos/foco.svg" alt=""></label></td>
    </tr>
    <tr>
      <th scope="row">1</th>
      <td>Servicio 1</td>
      <td>Nivel 3</td>
      <td>....</td>
      <td>....</td>
      <td><label for="" class="btn btn-success" style="border-radius:150px;"><img src="../iconos/foco.svg" alt=""></label></td>
    </tr>
    
  </tbody>

</table>
</section>
<!-- Tabla dentro del acordeon-->

      </div>
    </div>
  </div>
<!--Sección final del acordeon 1 -->


<!--Sección del acordeon 2 -->
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
        FINANCE
      </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">

<!-- Tabla dentro del acordeon-->
<section class="container card">
<table class="table container">
  <thead>
    <tr>
      <th scope="col">Numero</th>
      <th scope="col">Nombre del servicio</th>
      <th scope="col">Prioridad</th>
      <th scope="col">Descripcion</th>
      <th scope="col">Fecha y Hora</th>
      <th scope="col">Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Command Center, Gdl, Jalisco</td>
      <td></td>
      <td></td>
      <td>....</td>
      <td><label class="btn btn-success" style="border-radius:150px;"><img src="../iconos/foco.svg" alt=""></label></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Command Center, , India</td>
      <td>....</td>
      <td>....</td>
      <td>....</td>
      <td><label for="" class="btn btn-success" style="border-radius:150px;"><img src="../iconos/foco.svg" alt=""></label></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td colspan="2">Command Center, Shangai, China</td>
      <td>....</td>
      <td>....</td>
      <td><button class="btn btn-success" style="border-radius:150px;"><img src="../iconos/foco.svg" alt=""></button></td>
    </tr>
  </tbody>
</table>
</section>
<!-- Tabla dentro del acordeon-->

      </div>
    </div>
  </div>
<!--Sección del final de acordeon 2 -->


<!--Sección del acordeon 3 -->
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
        DEV
      </button>
    </h2>
    <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
    <div class="accordion-body">

<!-- Tabla dentro del acordeon-->
<section class="container card">
<table class="table container">
  <thead>
    <tr>
      <th scope="col">Numero</th>
      <th scope="col">Nombre del servicio</th>
      <th scope="col">Prioridad</th>
      <th scope="col">Descripcion</th>
      <th scope="col">Fecha y Hora</th>
      <th scope="col">Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Command Center, Gdl, Jalisco</td>
      <td></td>
      <td></td>
      <td>....</td>
      <td><label class="btn btn-success" style="border-radius:150px;"><img src="../iconos/foco.svg" alt=""></label></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Command Center, , India</td>
      <td>....</td>
      <td>....</td>
      <td>....</td>
      <td><label for="" class="btn btn-success" style="border-radius:150px;"><img src="../iconos/foco.svg" alt=""></label></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td colspan="2">Command Center, Shangai, China</td>
      <td>....</td>
      <td>....</td>
      <td><button class="btn btn-success" style="border-radius:150px;"><img src="../iconos/foco.svg" alt=""></button></td>
    </tr>
  </tbody>
</table>
</section>
<!-- Tabla dentro del acordeon-->

      </div>
    </div>
  </div>
<!--Sección final del acordeon 3 -->


<!--Sección del acordeon 4 -->
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFour">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseFour">
        RESEARCH
      </button>
    </h2>
    <div id="flush-collapseFour" class="accordion-collapse collapse" aria-labelledby="flush-headingFour" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body">

<!-- Tabla dentro del acordeon-->
<section class="container card">
<table class="table container">
  <thead>
    <tr>
      <th scope="col">Numero</th>
      <th scope="col">Nombre del servicio</th>
      <th scope="col">Prioridad</th>
      <th scope="col">Descripcion</th>
      <th scope="col">Fecha y Hora</th>
      <th scope="col">Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Command Center, Gdl, Jalisco</td>
      <td></td>
      <td></td>
      <td>....</td>
      <td><label class="btn btn-success" style="border-radius:150px;"><img src="../iconos/foco.svg" alt=""></label></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Command Center, , India</td>
      <td>....</td>
      <td>....</td>
      <td>....</td>
      <td><label for="" class="btn btn-success" style="border-radius:150px;"><img src="../iconos/foco.svg" alt=""></label></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td colspan="2">Command Center, Shangai, China</td>
      <td>....</td>
      <td>....</td>
      <td><button class="btn btn-success" style="border-radius:150px;"><img src="../iconos/foco.svg" alt=""></button></td>
    </tr>
  </tbody>
</table>
</section>
<!-- Tabla dentro del acordeon-->

      </div>
    </div>
  </div>
<!--Sección final del acordeon 4 -->


<!--Sección del acordeon 5 -->
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingFive">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFive" aria-expanded="false" aria-controls="flush-collapseFive">
        OPERATION  </button>     
    </h2>
    <div id="flush-collapseFive" class="accordion-collapse collapse" aria-labelledby="flush-headingFive" data-bs-parent="#accordionFlushExample">
    <div class="accordion-body"> 

<!-- Tabla dentro del acordeon-->
<section class="container card">
<table class="table container">
  <thead>
    <tr>
      <th scope="col">Numero</th>
      <th scope="col">Nombre del servicio</th>
      <th scope="col">Prioridad</th>
      <th scope="col">Descripcion</th>
      <th scope="col">Fecha y Hora</th>
      <th scope="col">Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Command Center, Gdl, Jalisco</td>
      <td></td>
      <td></td>
      <td>....</td>
      <td><label class="btn btn-success" style="border-radius:150px;"><img src="../iconos/foco.svg" alt=""></label></td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Command Center, , India</td>
      <td>....</td>
      <td>....</td>
      <td>....</td>
      <td><label for="" class="btn btn-success" style="border-radius:150px;"><img src="../iconos/foco.svg" alt=""></label></td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td colspan="2">Command Center, Shangai, China</td>
      <td>....</td>
      <td>....</td>
      <td><button class="btn btn-success" style="border-radius:150px;"><img src="../iconos/foco.svg" alt=""></button></td>
    </tr>
  </tbody>
</table>
</section>
<!-- Tabla dentro del acordeon-->

      </div>
    </div>
  </div>
<!--Sección final del acordeon 5 -->

</div>

</section>
<!--Sección final   -->

<p></p>

<!-- 3 columnas de los 3 command center -->
<section class="container">
  <div class="row">
      <div class="col-lg-4">
        <img class="bd-placeholder-img rounded-circle" width="140" height="140" src="../img/Mexico.png" role="img" aria-label="Placeholder" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="var(--bs-secondary-color)"/></img>
        <h2 class="fw-normal">Zapopan, Jalisco, México</h2>
        <p>Some representative placeholder content for the three columns of text below the carousel. This is the first column.</p>
        <p><a class="btn btn-secondary" href="#">Command Center 1 &raquo;</a></p>
      </div><!-- /.col-lg-4 -->
      <div class="col-lg-4">
        <img class="bd-placeholder-img rounded-circle" width="140" height="140" src="../img/India.png" role="img" aria-label="Placeholder" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="var(--bs-secondary-color)"/></img>
        <h2 class="fw-normal">Chennai, Tamil Nadu, India</h2>
        <p>Another exciting bit of representative placeholder content. This time, we've moved on to the second column.</p>
        <p><a class="btn btn-secondary" href="#">Command Center 2 &raquo;</a></p>
      </div><!-- /.col-lg-4 -->
      <div class="col-lg-4">
        <img class="bd-placeholder-img rounded-circle" width="140" height="140" src="../img/China.png" role="img" aria-label="Placeholder" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="var(--bs-secondary-color)"/></img>
        <h2 class="fw-normal">Wuxi, Shanghai, China</h2>
        <p>And lastly this, the third column of representative placeholder content.</p>
        <p><a class="btn btn-secondary" href="#">Command Center 3 &raquo;</a></p>
      </div><!-- /.col-lg-4 -->
    </div><!-- /.row -->
</section>

<p></p>

<!--Nueva seccion FOOTER AZ-->
<section class="">
  <!-- Footer -->
  <footer class="text-center text-white" style="background-color: #84075c;">
    <!-- Grid container -->
    <div class="container p-4 pb-0">
    <!-- Section: CTA -->
    <section class="">
      <p class="d-flex justify-content-center align-items-center">
      <span class="me-3"></span>
      <button type="button" class="btn btn-outline-light btn-rounded">
        App <img src="../iconos/movil.svg"  alt="">
      </button>
      </p>
    </section>
    <!-- Section: CTA -->
    </div>
    <!-- Grid container -->
  
    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2023 Copyright:
    <a class="text-white" href="">AstraZeneca</a>
    </div>
    <!-- Copyright -->
  </footer>
  <!-- Footer -->
  </section>
<!--final de nueva seccion FOOTER AZ-->



<script>
		// Seleccionar la lista de elementos
		var lista = document.getElementById("miLista");

		// Identificar los elementos por su prioridad
		var elementosUrgentes = lista.querySelectorAll(".Rojo");
		var elementosMedia = lista.querySelectorAll(".Amarillo");
		var elementosBajos = lista.querySelectorAll(".Verde");

		// Mover los elementos a la posición deseada en la lista según su prioridad
		for (var i = 0; i < elementosUrgentes.length; i++) {
			lista.insertBefore(elementosUrgentes[i], lista.firstChild);
		}
		for (var i = 0; i < elementosMedia.length; i++) {
			lista.insertBefore(elementosMedia[i], lista.lastChild);
		}
		for (var i = 0; i < elementosBajos.length; i++) {
			lista.insertBefore(elementosBajos[i], lista.lastChild);
		}
	</script>





 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
  crossorigin="anonymous"></script>
</body>
</html>