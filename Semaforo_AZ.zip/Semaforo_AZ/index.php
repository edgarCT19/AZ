<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel='shortcut icon' type='img/x-icon' href='img/favicon-removebg-preview.png'>

    <title>Iniciar sesión</title>

</head>
<body>
  <!--Formulario del login-->
  
    <section >
        <div class="container py-5 h-100">
          <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-xl-10">
              <div class="card rounded-3 text-black">
                <div class="row g-0">
                  <div class="col-lg-6">
                    <div class="card-body p-md-5 mx-md-4">
      
                      <div class="text-center">
                        <img src="img/AZ_LOGO.jpg"
                          style="width: 185px;" alt="logo">
                        <h4 class="mt-1 mb-5 pb-1">Inicia sesión en la plataforma AstraZeneca</h4>
                      </div>
      
                      <form>
                        <p>¡Por favor, inicie sesión con su cuenta AstraZeneca!</p>
      
                        <div class="form-outline mb-4">
                          <input type="email" id="form2Example11" class="form-control"
                            placeholder="Ej:Pedrito Perez/pedritofdz17@AstraZeneca.mx" />
                          <label class="form-label" for="form2Example11">Usuario</label>
                        </div>
      
                        <div class="form-outline mb-4">
                          <input type="password" id="form2Example22" class="form-control" />
                          <label class="form-label" for="form2Example22">Contraseña</label>
                        </div>
      
                        <div class="text-center pt-1 mb-5 pb-1">
                          <a href="../Principal_Cuenta/principal.php">
                          <button alert="Hola"  class="btn btn-warning text-black btn-block fa-lg gradient-custom-2 mb-3" type="button">Iniciar sesión
                        </button>
                           </a>
                        <p></p>
                          <a class="text-muted" href="http://localhost/AztraZeneca/Implementacion/ayuda.php">¿Olvidaste tu usuario o contraseña?</a>
                        </div>
      
                        <div class="d-flex align-items-center justify-content-center pb-4">
                          <p class="mb-0 me-2">¿No tienes cuenta?</p>
                          <div clas="col-xl-10">
                            <a href="http://localhost/AztraZeneca/Registros/Registro_Paciente.php">
                          <button type="button"  class="btn btn-warning text-black gradient-custom-2" data-toggle="modal" data-target="#create">
                            <span class="glyphicon glyphicon-plus"></span>Crear nueva</button>
                          </a>
                        </div>
                        </div>
                      </form>
      
                    </div>
                  </div>
                  <div class="col-lg-6 d-flex align-items-center gradient-custom-2">
                    <div class="text-black px-3 py-4 p-md-5 mx-md-4">
                      <h4 class="mb-4">AstraZeneca</h4>
                      <p class="small mb-0">“Nuestro reto se enfoca en desarrollar una solución en tiempo real que permita visualizar 
                        el estatus de los servicios categoría 1 de todos los Business Technology Groups (BTG´s Areas de Negocio) de AstraZeneca. 
                        Con el objetivo de obtener un mejor control y visibilidad, así como reducir los incidentes 
                        críticos en las aplicaciones y servicios que impactan las áreas de negocio y nuestro fin último que son los pacientes.”.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </section>

 <!-- Seccion del puro footer--> 
 <section class="">
  <!-- Footer -->
  <footer class="bg-dark text-center text-white">
    <!-- Grid container -->
    <div class="container p-4">
      <!-- Section: Social media -->
      <section class="mb-4">
        <!-- Facebook -->
        <a class="btn btn-outline-light btn-floating m-1" href="https://www.facebook.com/astrazenecamx?mibextid=ZbWKwL" role="button">
        <img src="iconos/facebook.svg" style="background-color: #fff;" alt=""></a>
  
        <!-- Twitter -->
        <a class="btn btn-outline-light btn-floating m-1" href="https://twitter.com/AstraZeneca?t=_QgFnKD5vbLiZbJto0k2DA&s=09" role="button">
        <img src="iconos/twitter.svg" alt="" style="background-color: #fff;"></a>
  
  
        <!-- Instagram -->
        <a class="btn btn-outline-light btn-floating m-1" href="https://instagram.com/astrazeneca?igshid=YmMyMTA2M2Y=" role="button">
        <img src="iconos/instagram.svg" alt="" style="background-color: #fff;"></a>
  
        <!-- Linkedin -->
        <a class="btn btn-outline-light btn-floating m-1" href="https://es.linkedin.com/company/astrazeneca" role="button">
        <img src="iconos/linkedin.svg" alt="" style="background-color: #fff;"></a>
  
        <!-- Youtube -->
        <a class="btn btn-outline-light btn-floating m-1" href="https://www.youtube.com/user/astrazeneca" role="button">
        <img src="iconos/youtube.svg" alt="" style="background-color: #fff;"></a>
  
      </section>
      <!-- Section: Social media -->
  
      <!-- Section: Form -->
      <section class="">
        <form action="">
          <!--Grid row-->
          <div class="row d-flex justify-content-center">
            <!--Grid column-->
            <div class="col-auto">
              <p class="pt-2">
                <strong>Conoce más de AztraZeneca</strong>
              </p>
            </div>
            <!--Grid column-->
          </div>
  
          <!--Grid row-->
        </form>
      </section>
      <!-- Section: Form -->
  
      <!-- Section: Text -->
      <section class="mb-4">
        <p>
          En astrazeneca  tu salud es nuestra prioridad, y en esta seccion te dejamos algunas recomendaciones
          que te servirán para conocernos y mejorar tu salud. Además te dejamos nuestras redes sociales e 
          información de nuestras multiples plataformas.
        </p>
      </section>
      <!-- Section: Text -->
  
      <!-- Section: Links -->
      <section class="">
        <!--Grid row-->
        <div class="row">
          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
            <h5 class="text-uppercase">Companía</h5>
  
            <ul class="list-unstyled mb-0">
              <li>
                <p>Está página es única y perteneciente de AstraZeneca.</p>
                <h3 class="text-white">Contáctenos al: 800-06-ASTRA (27872)</h3>
                          <!--Grid column-->
            <div class="col-auto">
              <!-- Submit button -->
              <button type="submit" class="btn btn-warning mb-4">
              <img src="/iconos/telefono.svg" alt="">
              </button>
            </div>
            <!--Grid column-->
              </li>
            </ul>
          </div>
          <!--Grid column-->
  
          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
            <h5 class="text-uppercase">Covid-19</h5>
  
            <ul class="list-unstyled mb-0">
              <li>
                <a href="https://www.youtube.com/watch?v=VYKS9EWmX_0" class="text-white">Video 1</a>
              </li>
              <li>
                <a href="https://www.youtube.com/user/astrazeneca" class="text-white">Video 2</a>
              </li>
              <li>
                <a href="https://www.youtube.com/watch?v=4G6KkTrsdI0" class="text-white">Video 3</a>
              </li>
              <li>
                <a href="https://www.youtube.com/watch?v=lYsLz1CsA4c" class="text-white">Video 4</a>
              </li>
            </ul>
          </div>
          <!--Grid column-->
  
          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
            <h5 class="text-uppercase">Vacuna y comprobante</h5>
  
            <ul class="list-unstyled mb-0">
              <li>
                <a href="https://www.azmed.com.mx/vacuna-covid-astrazeneca.html" class="text-white">Link 1</a>
              </li>
              <li>
                <a href="https://mivacuna.salud.gob.mx/index.php" class="text-white">Link 2</a>
              </li>
            </ul>
          </div>
          <!--Grid column-->
  
          <!--Grid column-->
          <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
            <h5 class="text-uppercase">Más recomendaciones</h5>
  
            <ul class="list-unstyled mb-0">
              <li>
                <a href="https://www.astrazeneca.mx/profesionales-de-la-salud.html" class="text-white">Link 1</a>
              </li>
              <li>
                <a href="https://www.azmed.com.mx/ria.html" class="text-white">Link 2</a>
              </li>
              <li>
                <a href="https://www.astrazeneca.com/our-therapy-areas/biopharmaceuticals.html" class="text-white">Link 3</a>
              </li>
              <li>
                <a href="https://www.astrazeneca.com/r-d/precision-medicine.html" class="text-white">Link 4</a>
              </li>
            </ul>
          </div>
          <!--Grid column-->
        </div>
        <!--Grid row-->
      </section>
      <!-- Section: Links -->
    </div>
    <!-- Grid container -->
  
    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
      © 2023 Copyright:
      <a class="text-white" href="https://www.astrazeneca.com/">AztraZeneca.com</a>
    </div>
    <!-- Copyright -->
  </footer>
  <!-- Footer -->
 </section>
 <!-- Footer seccion final-->

</body>
</html>